# 🔍 Code Scanning - Настройка

## 📊 Что это:

**Code Scanning** - автоматическое сканирование кода на уязвимости и ошибки.

### Что проверяет:
- ✅ **SQL Injection** - уязвимости в SQL запросах
- ✅ **XSS (Cross-Site Scripting)** - уязвимости в веб-приложениях
- ✅ **Hardcoded secrets** - захардкоженные пароли/ключи
- ✅ **Insecure dependencies** - небезопасные зависимости
- ✅ **Code quality** - качество кода, best practices

### Инструменты:
- **CodeQL** (GitHub) - основной инструмент
- **Semgrep** - альтернатива
- **SonarCloud** - внешний сервис

---

## ⚠️ **Рекомендация: ОПЦИОНАЛЬНО**

### Плюсы:
- 🔒 **Безопасность** - находит уязвимости в коде
- 📊 **Качество** - улучшает качество кода
- 🎯 **Hackathon** - показывает профессионализм

### Минусы:
- ⏱️ **Время** - требует настройки
- 🐌 **Скорость** - может замедлить CI/CD
- 🔧 **Сложность** - нужно настроить workflow

---

## 🛠️ **Как настроить:**

### **Вариант 1: CodeQL (GitHub Actions)**

1. Зайди на страницу Security overview
2. Найди "Code scanning alerts"
3. Нажми **"Set up code scanning"**
4. Выбери **"Set up with CodeQL"**
5. GitHub создаст workflow автоматически

### **Вариант 2: Вручную (GitHub Actions)**

Создай файл `.github/workflows/codeql.yml`:

```yaml
name: "CodeQL"

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]
  schedule:
    - cron: '0 0 * * 0'  # Каждое воскресенье

jobs:
  analyze:
    name: Analyze
    runs-on: ubuntu-latest
    permissions:
      actions: read
      contents: read
      security-events: write

    strategy:
      fail-fast: false
      matrix:
        language: [ 'javascript', 'python' ]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Initialize CodeQL
      uses: github/codeql-action/init@v2
      with:
        languages: ${{ matrix.language }}

    - name: Autobuild
      uses: github/codeql-action/autobuild@v2

    - name: Perform CodeQL Analysis
      uses: github/codeql-action/analyze@v2
```

---

## 📋 **Для нашего проекта:**

### **Языки:**
- **JavaScript** - фронтенд (HTML/JS)
- **Python** - бот (bot.py)
- **PHP** - API (tama_supabase.php)

### **Что будет сканироваться:**
- ✅ `tamagotchi-game.html` - JavaScript код
- ✅ `bot/bot.py` - Python код
- ✅ `api/tama_supabase.php` - PHP код
- ✅ Все `.js` файлы в `js/`

---

## ⏱️ **Время настройки:**

- **Автоматическая настройка:** 5 минут
- **Ручная настройка:** 15-30 минут
- **Первое сканирование:** 10-20 минут

---

## 🎯 **Рекомендация:**

### **Для хакатона:**
- ⚠️ **Опционально** - не обязательно
- ✅ Если есть время - включи
- ✅ Показывает профессионализм

### **Для продакшна:**
- ✅ **Рекомендуется** - включить обязательно
- ✅ Важно для безопасности
- ✅ Улучшает качество кода

---

## 🚀 **Действие:**

### **Быстрый способ:**
1. Зайди на Security overview
2. Нажми "Set up code scanning"
3. Выбери "Set up with CodeQL"
4. GitHub создаст workflow автоматически

### **Или я могу создать workflow файл:**
Могу создать `.github/workflows/codeql.yml` для автоматического сканирования.

---

## 💡 **Итог:**

- **Dependabot** - ✅ Включить (просто, полезно)
- **Code Scanning** - ⚠️ Опционально (сложнее, но полезно)

