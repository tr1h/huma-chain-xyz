# 🔧 Railway PHP Setup - Fix "php: command not found"

## 🐛 Проблема

```
/bin/bash: line 1: php: command not found
```

**Причина:** Railway не знает, что это PHP проект и не устанавливает PHP.

---

## ✅ Решение: Используй Nixpacks

Railway автоматически определит PHP проект через `nixpacks.toml`.

### Файл `nixpacks.toml` (УЖЕ СОЗДАН):

```toml
[phases.setup]
nixPkgs = ["php82", "php82Packages.composer"]

[phases.install]
cmds = ["composer install --no-dev --optimize-autoloader || true"]

[start]
cmd = "php -S 0.0.0.0:$PORT -t . api/tama_supabase.php"
```

Этот файл говорит Railway:
1. Установить PHP 8.2
2. Установить Composer (если нужен)
3. Запустить PHP встроенный сервер

---

## 🔄 Что делать сейчас:

### 1. Закоммить файлы (УЖЕ СДЕЛАНО)

Файлы уже созданы:
- ✅ `nixpacks.toml` - для Nixpacks
- ✅ `Dockerfile` - альтернатива (если Nixpacks не сработает)
- ✅ `Procfile` - альтернатива для Heroku-style

### 2. Перезапустить deployment в Railway

1. Открой Railway Dashboard
2. Выбери проект → Service
3. Нажми **"Redeploy"** или **"Deploy"**

Railway автоматически:
- Обнаружит `nixpacks.toml`
- Установит PHP 8.2
- Запустит сервер

---

## 🧪 Проверка:

После перезапуска проверь логи в Railway:

1. Открой Railway Dashboard → Service → Logs
2. **Ожидаемые сообщения:**
   ```
   Installing PHP 8.2...
   Starting PHP server on port $PORT...
   PHP 8.2.0 Development Server started
   ```

3. **НЕ должно быть:**
   ```
   ❌ php: command not found
   ```

---

## 🔄 Альтернативные варианты:

### Вариант 1: Dockerfile (если Nixpacks не работает)

Railway автоматически использует `Dockerfile`, если он есть.

**Преимущества:**
- Полный контроль над окружением
- Можно использовать Apache/Nginx

**Недостатки:**
- Больше размер образа
- Дольше сборка

### Вариант 2: Procfile (Heroku-style)

Railway также поддерживает `Procfile`:

```
web: php -S 0.0.0.0:$PORT -t . api/tama_supabase.php
```

---

## 📊 Приоритет использования:

1. **`nixpacks.toml`** - основной (быстрый, автоматический)
2. **`Dockerfile`** - если Nixpacks не работает
3. **`Procfile`** - если нужен Heroku-style

---

## ✅ После исправления:

- ✅ PHP установлен
- ✅ Сервер запускается
- ✅ API отвечает
- ✅ Нет ошибок "command not found"

---

## 🎯 Следующие шаги:

1. **Добавь переменные окружения** в Railway (если ещё не добавил):
   - `SUPABASE_URL`
   - `SUPABASE_KEY`
   - `TAMA_MINT_ADDRESS`

2. **Перезапусти deployment** в Railway

3. **Проверь логи** - должно быть "PHP server started"

4. **Проверь API:**
   ```
   curl https://huma-chain-xyz-production.up.railway.app/api/tama/test
   ```

---

**Status:** ✅ FIXED - Configuration files created  
**Date:** November 7, 2025  
**Next Step:** Redeploy in Railway Dashboard

