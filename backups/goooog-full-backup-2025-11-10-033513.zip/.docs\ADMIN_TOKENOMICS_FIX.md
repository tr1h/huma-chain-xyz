# 🔧 Исправление админки токеномики

## 🐛 Проблема:

**Ошибка:** `column tama_transactions.type does not exist`

**Причина:** 
- Таблица `tama_transactions` не существует в Supabase
- Или структура таблицы другая

---

## ✅ Решение:

### **1. Обновлен код админки:**
- Теперь пробует несколько вариантов таблиц:
  1. `tama_economy` с колонкой `transaction_type`
  2. `withdrawals` 
  3. `leaderboard` с колонкой `total_withdrawn`

### **2. Создан SQL скрипт:**
- Файл: `sql/create_withdrawals_table.sql`
- Создает правильные таблицы в Supabase

---

## 🔧 Что нужно сделать:

### **Вариант 1: Создать таблицу в Supabase (рекомендуется)**

1. Зайди в Supabase Dashboard
2. SQL Editor → New Query
3. Скопируй содержимое `sql/create_withdrawals_table.sql`
4. Выполни запрос

### **Вариант 2: Использовать существующую таблицу**

Если у тебя уже есть таблица с выводами:
- Проверь её название и структуру
- Админка автоматически попробует найти данные

---

## 📊 Структура таблицы (рекомендуемая):

### **tama_economy:**
```sql
- id (BIGSERIAL)
- telegram_id (TEXT)
- transaction_type (TEXT) -- 'withdrawal', 'earning', etc
- amount (BIGINT)
- fee (BIGINT)
- signature (TEXT)
- wallet_address (TEXT)
- created_at (TIMESTAMP)
```

### **Или withdrawals:**
```sql
- id (BIGSERIAL)
- telegram_id (TEXT)
- amount (BIGINT)
- wallet_address (TEXT)
- tx_signature (TEXT)
- created_at (TIMESTAMP)
```

---

## 🚀 После создания таблицы:

1. Обнови страницу админки
2. Данные должны загрузиться автоматически
3. Если выводы были - они появятся в таблице

---

## ✅ Статус:

- [x] Код обновлен (поддержка нескольких таблиц)
- [x] SQL скрипт создан
- [ ] Таблица создана в Supabase (нужно сделать вручную)

---

## 💡 Что дальше:

1. Создай таблицу в Supabase (используй SQL скрипт)
2. Обнови админку
3. Проверь работу

