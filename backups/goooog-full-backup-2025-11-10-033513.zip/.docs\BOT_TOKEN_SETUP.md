# 🤖 Настройка Telegram Bot Token

## 🔒 Безопасность

**ВАЖНО:** Токены НЕ должны быть в коде! Используй переменные окружения или `.env` файл.

---

## 📋 Способы установки токена:

### **Способ 1: Переменные окружения (PowerShell)**

```powershell
# Установи токен
$env:TELEGRAM_BOT_TOKEN = "8445221254:AAE3F6Bha29dS-zzWOmJhz26K9u6lfBUu1g"

# Запусти бота
cd C:\goooog\bot
.\start_bot.ps1
```

### **Способ 2: .env файл (рекомендуется)**

1. Создай файл `C:\goooog\bot\.env`:
```
TELEGRAM_BOT_TOKEN=8445221254:AAE3F6Bha29dS-zzWOmJhz26K9u6lfBUu1g
BOT_USERNAME=GotchiGameBot
SUPABASE_URL=https://zfrazyupameidxpjihrh.supabase.co
SUPABASE_KEY=твой_supabase_key
```

2. Запусти бота:
```powershell
cd C:\goooog\bot
.\start_bot.ps1
```

### **Способ 3: Системные переменные окружения**

1. Открой "Системные переменные среды" в Windows
2. Добавь `TELEGRAM_BOT_TOKEN` = `8445221254:AAE3F6Bha29dS-zzWOmJhz26K9u6lfBUu1g`
3. Перезапусти PowerShell
4. Запусти бота

---

## ✅ Проверка

После установки токена, бот должен запуститься без ошибок:
```
Starting Gotchi Game Bot...
Environment variables set:
  BOT_USERNAME: GotchiGameBot
  ...
Bot started!
```

---

## 🔐 Текущий токен:

```
8445221254:AAE3F6Bha29dS-zzWOmJhz26K9u6lfBUu1g
```

**Храни его в безопасности!** Не коммить в Git!

---

## ⚠️ Если токен скомпрометирован:

1. Зайди в @BotFather
2. Выбери своего бота
3. `/revoke` - отозвать старый токен
4. `/newtoken` - создать новый токен
5. Обнови токен в переменных окружения

