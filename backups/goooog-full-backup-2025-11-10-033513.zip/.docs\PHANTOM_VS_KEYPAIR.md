# 🔑 PHANTOM VS KEYPAIR - КАК ПОДКЛЮЧИТЬСЯ

## ❓ ВОПРОС: "Чтобы подключиться мне нужен Phantom правильно? Где взять ключи для кошелька?"

**ОТВЕТ:** Зависит от того, **как** ты хочешь использовать кошелек!

---

## 🎯 ДВА СПОСОБА РАБОТЫ С КОШЕЛЬКОМ

### **1. CLI команды (spl-token, solana) - НЕ нужен Phantom!**

```
Используется: Keypair файл (.json)
├─ У тебя уже есть: team-wallet-keypair.json ✅
├─ Используется в командах: --owner, --keypair
└─ НЕ нужен Phantom!
```

**Пример:**
```bash
# Используется keypair файл, НЕ Phantom!
spl-token accounts --owner AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR --url devnet

# Или с keypair файлом:
spl-token accounts -k C:\goooog\team-wallet-keypair.json --url devnet
```

---

### **2. Веб-интерфейс (Streamflow.finance) - НУЖЕН Phantom!**

```
Используется: Phantom кошелек (браузерное расширение)
├─ Нужно установить: Phantom расширение
├─ Нужно импортировать: keypair в Phantom
└─ Используется для: веб-интерфейса Streamflow
```

---

## 🔧 КАК ИМПОРТИРОВАТЬ KEYPAIR В PHANTOM

### **Шаг 1: Установить Phantom**

1. Открой: https://phantom.app/
2. Установи расширение для браузера
3. Создай новый кошелек (или пропусти, если импортируешь)

---

### **Шаг 2: Импортировать существующий keypair**

#### **Вариант A: Через приватный ключ (Secret Key)**

```bash
# 1. Получить приватный ключ из keypair файла
# Keypair файл содержит массив чисел - это и есть приватный ключ
```

**В Phantom:**
1. Открой Phantom
2. Нажми "Settings" → "Add/Connect Wallet"
3. Выбери "Import Private Key"
4. Вставь приватный ключ (массив чисел из JSON файла)

**Как получить приватный ключ:**
```javascript
// Из team-wallet-keypair.json
// Это массив чисел, например: [123, 45, 67, ...]
// Нужно конвертировать в base58 или использовать как есть
```

---

#### **Вариант B: Через Seed Phrase (если есть)**

Если у тебя есть seed phrase для team wallet:
1. В Phantom: "Import Existing Wallet"
2. Введи seed phrase
3. Готово!

**НО:** У тебя keypair файл, а не seed phrase, так что этот вариант не подходит.

---

#### **Вариант C: Через Base58 приватный ключ**

```bash
# Конвертировать keypair в base58 формат
# Phantom может импортировать base58 приватный ключ
```

**Как конвертировать:**
```javascript
// Используй Solana CLI или скрипт для конвертации
// Keypair JSON → Base58 приватный ключ
```

---

## 📋 ПРАКТИЧЕСКОЕ РЕШЕНИЕ

### **Для CLI команд (сейчас):**

```
✅ НЕ нужен Phantom!
✅ Используется keypair файл: team-wallet-keypair.json
✅ Все команды работают с --owner или --keypair
```

**Пример:**
```bash
# Проверка баланса - использует keypair файл
spl-token accounts -k C:\goooog\team-wallet-keypair.json --url devnet

# Или через адрес (если keypair в config)
spl-token accounts --owner AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR --url devnet
```

---

### **Для веб-интерфейса Streamflow:**

```
⚠️ НУЖЕН Phantom!
⚠️ Нужно импортировать keypair в Phantom
```

**Как импортировать:**

1. **Установи Phantom:** https://phantom.app/
2. **Получи приватный ключ из keypair:**
   ```javascript
   // team-wallet-keypair.json содержит массив чисел
   // Это и есть приватный ключ
   ```
3. **В Phantom:**
   - Settings → Add/Connect Wallet
   - Import Private Key
   - Вставь приватный ключ (массив чисел)

---

## 🔑 ГДЕ ВЗЯТЬ КЛЮЧИ

### **У тебя УЖЕ ЕСТЬ ключи!**

```
Файл: C:\goooog\team-wallet-keypair.json
├─ Содержит: Приватный ключ (массив чисел)
├─ Адрес: AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR
└─ Используется: Для CLI команд
```

**Этот файл и есть твои ключи!**

---

## 💡 РЕКОМЕНДАЦИЯ

### **Для создания vesting stream:**

**Вариант 1: CLI (через SDK) - НЕ нужен Phantom**
```
✅ Используется: team-wallet-keypair.json
✅ Не нужен Phantom
❌ Но есть проблема с SDK (InsufficientFunds)
```

**Вариант 2: Веб-интерфейс - НУЖЕН Phantom**
```
✅ Проще и надежнее
⚠️ Нужно импортировать keypair в Phantom
✅ Обычно работает без проблем
```

---

## 🔧 КАК ИМПОРТИРОВАТЬ KEYPAIR В PHANTOM (ДЕТАЛЬНО)

### **Метод 1: Через массив чисел (Secret Key)**

1. Открой `team-wallet-keypair.json`
2. Скопируй массив чисел (например: `[123, 45, 67, ...]`)
3. В Phantom:
   - Settings → Add/Connect Wallet
   - Import Private Key
   - Вставь массив чисел
   - Или конвертируй в base58 (если Phantom требует)

---

### **Метод 2: Через Solana CLI (конвертация)**

```bash
# Конвертировать keypair в формат для Phantom
solana-keygen pubkey C:\goooog\team-wallet-keypair.json --outfile team-wallet-pubkey.txt
```

**Но для импорта нужен приватный ключ, а не публичный!**

---

### **Метод 3: Использовать скрипт для конвертации**

Создам скрипт для конвертации keypair в формат для Phantom.

---

## ✅ ИТОГО

### **Для CLI команд:**
```
✅ НЕ нужен Phantom
✅ Используется: team-wallet-keypair.json
✅ Все работает!
```

### **Для веб-интерфейса:**
```
⚠️ НУЖЕН Phantom
⚠️ Нужно импортировать keypair
✅ Проще для создания vesting stream
```

### **Где ключи:**
```
✅ У тебя УЖЕ ЕСТЬ: C:\goooog\team-wallet-keypair.json
✅ Это и есть твои ключи!
✅ Адрес: AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR
```

---

**Готово! Теперь понятно как работать с ключами!** 🔑

