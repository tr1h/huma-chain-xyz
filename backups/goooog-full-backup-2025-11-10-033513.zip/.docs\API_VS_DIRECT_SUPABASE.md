# 🔥 API vs Direct Supabase - Why API is Better

## ❌ Проблема (прямое обращение к Supabase):

```javascript
// BAD: Direct Supabase call from frontend
const response = await fetch(`${SUPABASE_URL}/rest/v1/leaderboard?telegram_id=eq.${userId}`, {
    method: 'PATCH',
    headers: {
        'apikey': SUPABASE_ANON_KEY,  // ⚠️ EXPOSED KEY!
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({ tama: gameState.tama, ... })
});
```

### Недостатки:
1. ❌ **Ключи Supabase видны в frontend** (можно украсть)
2. ❌ **Нет валидации данных** (читер может отправить что угодно)
3. ❌ **Нет бизнес-логики** (NFT boost, античит, логирование)
4. ❌ **CORS проблемы** (если не настроен правильно)
5. ❌ **Нет централизации** (логика размазана по фронтенду)

---

## ✅ Решение (использовать собственный API):

```javascript
// GOOD: Use our API
const apiUrl = `${TAMA_API_BASE}/leaderboard/upsert`;
const response = await fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        user_id: userId,
        tama: gameState.tama,
        level: gameState.level,
        pet_data: pet_data,
        ...
    })
});
```

### Преимущества:
1. ✅ **Безопасность** - ключи Supabase скрыты на сервере
2. ✅ **Валидация** - API проверяет данные перед сохранением
3. ✅ **Бизнес-логика** - NFT boost, античит, логирование транзакций
4. ✅ **CORS настроен** - специально для фронтенда
5. ✅ **Централизация** - вся логика в одном месте
6. ✅ **Расширяемость** - легко добавить новые фичи

---

## 🔧 Наш API Endpoint

### POST `/api/tama/leaderboard/upsert`

**Request:**
```json
{
  "user_id": "7401131043",
  "user_type": "telegram",
  "tama": 21383,
  "level": 9,
  "xp": 850,
  "pet_data": {
    "hp": 100,
    "food": 80,
    "happy": 90,
    "totalClicks": 1234,
    "maxCombo": 50,
    ...
  },
  "pet_name": "Gotchi",
  "pet_type": "kawai"
}
```

**Response (Success):**
```json
{
  "success": true,
  "message": "Game data updated successfully",
  "data": {
    "user_id": "7401131043",
    "tama": 21383,
    "level": 9
  }
}
```

**Response (Error):**
```json
{
  "error": "user_id is required"
}
```

---

## 📊 Что делает API:

1. **Валидирует данные:**
   - Проверяет наличие `user_id`
   - Проверяет, что `tama` не null
   - Валидирует типы данных

2. **Безопасно обновляет данные:**
   - Проверяет, существует ли пользователь
   - Если да - UPDATE
   - Если нет - INSERT (с дефолтными значениями)

3. **Логирует активность:**
   - Обновляет `last_activity` timestamp
   - Можно добавить логирование транзакций

4. **Можно расширить:**
   - Применение NFT boost
   - Проверка античита (макс. клики в минуту)
   - Валидация Level-up прогрессии
   - Логирование в `transactions` таблицу

---

## 🔥 Сравнение

| Feature | Direct Supabase | Our API |
|---------|----------------|---------|
| **Безопасность** | ❌ Ключи в frontend | ✅ Ключи на сервере |
| **Валидация** | ❌ Нет | ✅ Да |
| **Бизнес-логика** | ❌ Нет | ✅ Да (NFT boost, античит) |
| **CORS** | ⚠️ Нужно настраивать | ✅ Уже настроен |
| **Логирование** | ❌ Нет | ✅ Да (транзакции) |
| **Расширяемость** | ❌ Тяжело | ✅ Легко |
| **Скорость** | 🟢 Fast | 🟢 Fast (one extra hop) |

---

## 🎯 Вывод

**ВСЕГДА используй API вместо прямого обращения к Supabase!**

- Это **правильная архитектура**
- Это **безопаснее**
- Это **легче поддерживать**
- Это **проще расширять**

---

## 📝 Files Modified

- **`api/tama_supabase.php`** - Added `/leaderboard/upsert` endpoint
- **`tamagotchi-game.html`** - Updated `saveDirectToSupabase()` to use API

---

**Status:** ✅ IMPLEMENTED  
**Date:** November 7, 2025  
**API URL:** `https://huma-chain-xyz-production.up.railway.app/api/tama/leaderboard/upsert`

