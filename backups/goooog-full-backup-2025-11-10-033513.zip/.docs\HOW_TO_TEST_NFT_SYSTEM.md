# 🧪 Как проверить NFT систему

## 📋 Быстрая проверка (5 минут)

### 1️⃣ Создать таблицы в Supabase

1. Открой **Supabase Dashboard** → **SQL Editor**
2. Скопируй содержимое файла **`create_nft_tiers_table.sql`**
3. Вставь в SQL Editor и нажми **Run**
4. Должно быть: `Success. No rows returned`

### 2️⃣ Проверить админку

1. Открой **`admin-nft-tiers.html`** в браузере
2. Должны загрузиться 3 тира (Bronze/Silver/Gold)
3. Попробуй изменить цену и нажать **Save**
4. Должно появиться: `✅ BRONZE tier saved successfully!`

### 3️⃣ Запустить тест-скрипт

```bash
python test_nft_system.py
```

**Ожидаемый результат:**
```
✅ Таблица 'nft_tiers' существует
✅ Таблица 'user_nfts' существует
✅ Пользователь БЕЗ NFT: 1.0x
✅ NFT зарегистрирован!
✅ SQL функция работает!
```

### 4️⃣ Проверить бота

1. Запусти бота: `cd bot && python bot.py`
2. В боте выполни: `/daily` (или любую команду с наградой)
3. Проверь логи бота - должно быть:
   ```
   🎁 NFT Boost applied: 100 TAMA × 2.0x = 200 TAMA
   ```

---

## 🔍 Детальная проверка

### Тест 1: Пользователь БЕЗ NFT

**Ожидаемое поведение:**
- Множитель = **1.0x**
- Заработок обычный (без увеличения)

**Как проверить:**
```python
from bot.nft_system import NFTSystem
nft_system = NFTSystem(supabase)

multiplier = nft_system.get_user_multiplier("YOUR_TELEGRAM_ID")
print(f"Multiplier: {multiplier}x")  # Должно быть 1.0
```

### Тест 2: Пользователь С NFT

**Ожидаемое поведение:**
- Множитель = **2.0-4.0x** (зависит от тира и редкости)
- Заработок увеличен

**Как проверить:**
```python
# Регистрация NFT
success, msg, mult = nft_system.register_nft_mint(
    telegram_id="YOUR_TELEGRAM_ID",
    nft_mint_address="TEST_NFT_123",
    tier_name="Bronze",
    rarity="Common"
)

# Проверка множителя
multiplier = nft_system.get_user_multiplier("YOUR_TELEGRAM_ID")
print(f"Multiplier: {multiplier}x")  # Должно быть 2.0 для Bronze Common
```

### Тест 3: Применение множителя в боте

**Ожидаемое поведение:**
- При вызове `add_tama_reward(user_id, 100)`:
  - Без NFT: начисляется **100 TAMA**
  - С NFT (2.0x): начисляется **200 TAMA**

**Как проверить:**
1. Запусти бота
2. Выполни команду с наградой (`/daily`, `/games`, и т.д.)
3. Проверь логи:
   ```
   🎁 NFT Boost applied: 100 TAMA × 2.0x = 200 TAMA
   ```

---

## 🐛 Решение проблем

### ❌ "Table 'nft_tiers' does not exist"

**Решение:**
1. Открой Supabase → SQL Editor
2. Запусти `create_nft_tiers_table.sql`
3. Проверь: `SELECT * FROM nft_tiers;`

### ❌ "Function 'get_user_nft_multiplier' does not exist"

**Решение:**
1. Проверь, что SQL функция создана в `create_nft_tiers_table.sql`
2. Запусти SQL файл полностью (не только CREATE TABLE)
3. Проверь: `SELECT get_user_nft_multiplier('7401131043');`

### ❌ "NFT multiplier не применяется"

**Решение:**
1. Проверь, что `nft_system` инициализирован в `bot.py`:
   ```python
   nft_system = NFTSystem(supabase)
   ```
2. Проверь, что `add_tama_reward()` вызывает `nft_system.get_user_multiplier()`
3. Перезапусти бота

### ❌ "Admin panel не загружает цены"

**Решение:**
1. Проверь Supabase URL и KEY в `admin-nft-tiers.html`
2. Проверь, что таблица `nft_tiers` заполнена (должно быть 3 строки)
3. Открой консоль браузера (F12) и проверь ошибки

---

## 📊 Проверка через SQL

### Проверить тиры:
```sql
SELECT * FROM nft_tiers;
```

**Ожидаемый результат:**
```
tier_name | tama_price | sol_price | base_multiplier
----------|------------|-----------|----------------
Bronze    | 2500       | 0.05      | 2.0
Silver    | 5000       | 0.1       | 2.5
Gold      | 10000      | 0.2       | 3.0
```

### Проверить NFT пользователя:
```sql
SELECT * FROM user_nfts WHERE telegram_id = 'YOUR_TELEGRAM_ID';
```

### Проверить множитель:
```sql
SELECT get_user_nft_multiplier('YOUR_TELEGRAM_ID');
```

---

## ✅ Чеклист проверки

- [ ] Таблицы созданы в Supabase
- [ ] SQL функция работает
- [ ] Админка загружает цены
- [ ] Тест-скрипт проходит успешно
- [ ] Бот применяет множитель (логи)
- [ ] Пользователь БЕЗ NFT = 1.0x
- [ ] Пользователь С NFT = 2.0-4.0x
- [ ] Награды умножаются правильно

---

## 🎯 Быстрый тест (30 секунд)

```bash
# 1. Запусти тест
python test_nft_system.py

# 2. Если все ✅ - система работает!
# 3. Если ❌ - смотри "Решение проблем" выше
```

---

**Готово!** 🚀

