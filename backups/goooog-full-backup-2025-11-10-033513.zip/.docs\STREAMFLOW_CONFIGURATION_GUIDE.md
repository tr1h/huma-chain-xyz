# ⚙️ КОНФИГУРАЦИЯ VESTING STREAM В STREAMFLOW

## 📋 ПАРАМЕТРЫ ДЛЯ ЗАПОЛНЕНИЯ

### **1. Token** ✅
```
Уже выбран: Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY
```
**Оставь как есть!**

---

### **2. Vesting Duration** ⚠️ ИЗМЕНИТЬ!

```
Текущее: 1 Month
Нужно: 48 Months (4 года)
```

**Действия:**
- Измени "1" на "48"
- Выбери "Month" (или "Year" и поставь "4")

---

### **3. Unlock schedule** ⚠️ ИЗМЕНИТЬ!

```
Текущее: Bi-weekly
Нужно: Daily или Continuous (для linear unlock)
```

**Выбери:**
- "Daily" (ежедневно) - рекомендуется
- Или "Continuous" (непрерывно) - если есть такая опция

---

### **4. Vesting start date** ⚠️ ИЗМЕНИТЬ!

```
Текущее: "Upon contract creation" (включено)
Нужно: Отключить и установить дату через 6 месяцев
```

**Действия:**
1. Отключи переключатель "Upon contract creation"
2. Выбери дату: **2026-05-06** (через 6 месяцев от сегодня)

---

### **5. Cliff configuration** ⚠️ ВКЛЮЧИТЬ!

```
Текущее: "Add cliff amount" (выключено)
Нужно: Включить и установить 0 или период 6 месяцев
```

**Действия:**
1. Включи переключатель "Add cliff amount"
2. Установи:
   - **Cliff Amount:** 0 (полная блокировка)
   - **Cliff Period:** 6 месяцев (если есть такая опция)

---

### **6. Who can change the recipient?** ⚠️ ИЗМЕНИТЬ!

```
Текущее: "Only Recipient"
Нужно: "Neither" (максимальная безопасность)
```

**Действия:**
1. Открой выпадающий список
2. Выбери **"Neither"** (никто не может изменить recipient)
3. Это стандартная практика для team vesting

---

### **7. Preferences** ✅

#### **Cancellable:**
```
Текущее: Выключено ✅
Оставь выключенным!
```

#### **Auto-claim:**
```
Текущее: Выключено ✅
Оставь выключенным (вывод вручную)
```

#### **List for sale:**
```
Текущее: Выключено ✅
Оставь выключенным
```

---

## 📊 ИТОГОВАЯ КОНФИГУРАЦИЯ

```
Token: Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY ✅
Vesting Duration: 48 Months (или 4 Years) ⚠️
Unlock schedule: Daily ⚠️
Vesting start date: 2026-05-06 (через 6 месяцев) ⚠️
Cliff: Включить, Amount: 0, Period: 6 months ⚠️
Recipient change: Only Recipient (или No one) ✅
Cancellable: Выключено ✅
Auto-claim: Выключено ✅
List for sale: Выключено ✅
```

---

## 🎯 ЧТО ДОЛЖНО ПОЛУЧИТЬСЯ

После заполнения:
- ✅ График покажет разблокировку через 6 месяцев
- ✅ Полная разблокировка через 4 года
- ✅ Linear unlock (постепенно)

---

**Заполни форму и нажми "Continue" или "Create Stream"!** 🚀

