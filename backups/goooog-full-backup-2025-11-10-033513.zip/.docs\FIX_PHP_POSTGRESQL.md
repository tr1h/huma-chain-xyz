# 🔧 Исправление: PostgreSQL драйвер для PHP

## 🐛 Проблема:

```
{"error":"Database connection failed: could not find driver"}
```

**Причина:** Расширение `pdo_pgsql` не включено в PHP

---

## ✅ Решение:

### **Автоматически (уже сделано):**

Расширения раскомментированы в `C:\xampp\php\php.ini`:
- `extension=pdo_pgsql`
- `extension=pgsql`

### **Вручную (если нужно):**

1. Открой `C:\xampp\php\php.ini` в блокноте
2. Найди строки:
   ```ini
   ;extension=pdo_pgsql
   ;extension=pgsql
   ```
3. Убери `;` в начале:
   ```ini
   extension=pdo_pgsql
   extension=pgsql
   ```
4. Сохрани файл

---

## 🔍 Проверка:

```powershell
C:\xampp\php\php.exe -m | Select-String -Pattern "pdo_pgsql"
```

Должно показать: `pdo_pgsql`

---

## ⚠️ Важно:

**Перезапусти API сервер** после изменения php.ini!

1. Закрой окно API (Ctrl+C)
2. Запусти снова:
   ```powershell
   cd C:\goooog\api
   .\start_api.ps1
   ```

Или перезапусти всё:
```powershell
cd C:\goooog
.\start_bot_and_api.ps1
```

---

## ✅ Готово!

После перезапуска API должен подключиться к Supabase!

