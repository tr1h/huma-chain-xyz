# ✅ Проверка NFT Boost в Production

## 🎯 Что проверяем

NFT множитель (2-4x) должен **автоматически применяться** ко всем наградам в боте.

---

## 📋 Шаги проверки

### 1. Запустить бота
```bash
cd bot
python bot.py
```

### 2. В Telegram боте выполнить команду с наградой

Попробуй любую из этих команд:
- `/daily` - ежедневная награда
- `/games` - мини-игры
- `/quests` - квесты
- Кликни на питомца (в игре)

### 3. Проверить логи бота

В консоли бота должна быть запись:

```
🎁 NFT Boost applied: 100 TAMA × 2.0x = 200 TAMA
```

**Если такой записи НЕТ** → NFT множитель не применяется

---

## 🔍 Детальная проверка

### Тест 1: Пользователь БЕЗ NFT

1. Выполни `/daily` с аккаунта без NFT
2. Проверь логи:
   ```
   Нет строки "NFT Boost applied" - правильно!
   Пользователь получил обычную награду
   ```
3. ✅ **Ожидается:** награда без множителя (1.0x)

### Тест 2: Пользователь С NFT (Bronze Common = 2.0x)

1. Зарегистрируй тестовый NFT в Supabase:
   ```sql
   INSERT INTO user_nfts (telegram_id, nft_mint_address, tier_name, rarity, earning_multiplier, is_active)
   VALUES ('7401131043', 'TEST_NFT_123', 'Bronze', 'Common', 2.0, TRUE);
   ```

2. Выполни `/daily` с этого аккаунта

3. Проверь логи:
   ```
   🎁 NFT Boost applied: 1100 TAMA × 2.0x = 2200 TAMA
   ```

4. ✅ **Ожидается:** награда удвоена (2.0x)

### Тест 3: Пользователь С NFT (Gold Legendary = 4.0x)

1. Зарегистрируй NFT с максимальным бустом:
   ```sql
   INSERT INTO user_nfts (telegram_id, nft_mint_address, tier_name, rarity, earning_multiplier, is_active)
   VALUES ('ANOTHER_USER_ID', 'TEST_NFT_456', 'Gold', 'Legendary', 4.0, TRUE);
   ```

2. Выполни `/daily` с этого аккаунта

3. Проверь логи:
   ```
   🎁 NFT Boost applied: 1100 TAMA × 4.0x = 4400 TAMA
   ```

4. ✅ **Ожидается:** награда x4 (4.0x)

---

## 🐛 Если множитель не работает

### Проверка 1: NFT система инициализирована?

Проверь в `bot/bot.py`:

```python
# Должно быть:
from nft_system import NFTSystem
nft_system = NFTSystem(supabase)
```

### Проверка 2: Функция `add_tama_reward` использует множитель?

Проверь в `bot/bot.py` функцию `add_tama_reward`:

```python
def add_tama_reward(telegram_id, amount, source="game", apply_nft_multiplier=True):
    # ...
    if apply_nft_multiplier:
        try:
            multiplier = nft_system.get_user_multiplier(telegram_id)
            if multiplier > 1.0:
                amount = int(amount * multiplier)
                print(f"🎁 NFT Boost applied: {original_amount} TAMA × {multiplier}x = {amount} TAMA")
        except Exception as e:
            print(f"Error applying NFT multiplier: {e}")
    # ...
```

### Проверка 3: Таблица `user_nfts` существует?

Выполни в Supabase:

```sql
SELECT * FROM user_nfts WHERE telegram_id = '7401131043';
```

Должен вернуть NFT с `earning_multiplier`.

### Проверка 4: SQL функция работает?

Выполни в Supabase:

```sql
SELECT get_user_nft_multiplier('7401131043');
```

Должен вернуть множитель (2.0-4.0 если есть NFT, 1.0 если нет).

---

## ✅ Успешная проверка

Если видишь в логах:
```
🎁 NFT Boost applied: 100 TAMA × 2.0x = 200 TAMA
```

**Система работает правильно!** ✅

---

## 📊 Примеры наград с множителем

| Награда         | Без NFT | Bronze (2x) | Silver (3x) | Gold (4x) |
|-----------------|---------|-------------|-------------|-----------|
| /daily (1100)   | 1,100   | 2,200       | 3,300       | 4,400     |
| Клик питомца (1)| 1       | 2           | 3           | 4         |
| Quest (500)     | 500     | 1,000       | 1,500       | 2,000     |
| Referral (1000) | 1,000   | 2,000       | 3,000       | 4,000     |

---

## 🚀 Финальный тест

1. Открой бота
2. Выполни `/daily`
3. Скриншот логов бота
4. Отправь скриншот

**Ожидаемый результат:**
```
✅ Daily Reward Claimed!
💰 Reward: +2,200 TAMA (с учетом 2x буста)
🔥 Streak: 1 days in a row

Логи:
🎁 NFT Boost applied: 1100 TAMA × 2.0x = 2200 TAMA
```

---

**Готово!** 🎉

