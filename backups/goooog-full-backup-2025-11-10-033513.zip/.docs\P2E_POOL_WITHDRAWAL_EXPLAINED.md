# 💰 P2E POOL И ВЫВОД ТОКЕНОВ - КАК ЭТО РАБОТАЕТ?

## ❓ ВОПРОС: "При выводе минтится с какого адреса? Как участвует P2E Pool?"

**ОТВЕТ:** Сейчас используется `payer-keypair.json`, но **ПРАВИЛЬНО** должно быть из **P2E Pool**! ✅

---

## 🔍 ТЕКУЩАЯ РЕАЛИЗАЦИЯ (ЧТО СЕЙЧАС)

### Как работает СЕЙЧАС:

```php
// api/tama_supabase.php
$payerKeypair = 'payer-keypair.json';  // ← Используется СЕЙЧАС
$mintKeypair = 'tama-mint-keypair.json';

// spl-token transfer
spl-token transfer \
  Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY \
  9500 \
  USER_WALLET \
  --owner payer-keypair.json \  // ← Отсюда берутся токены
  --fee-payer payer-keypair.json
```

**Проблема:**
- ❌ Используется `payer-keypair.json` (технический кошелёк)
- ❌ P2E Pool НЕ используется напрямую
- ❌ Токены минтится с mint authority, а не из P2E Pool

---

## ✅ ПРАВИЛЬНАЯ РЕАЛИЗАЦИЯ (КАК ДОЛЖНО БЫТЬ)

### Как должно работать:

```
┌─────────────────────────────────────────┐
│  P2E POOL (400M TAMA)                   │
│  Адрес: HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw
│                                          │
│  Это ОСНОВНОЙ источник токенов!         │
│  Отсюда должны браться токены для       │
│  выплат игрокам                         │
└─────────────────────────────────────────┘
                    │
                    │ /withdraw 10000
                    ▼
┌─────────────────────────────────────────┐
│  ПРОЦЕСС ВЫВОДА                          │
├─────────────────────────────────────────┤
│  1. Списать виртуальные из базы          │
│  2. Transfer из P2E Pool                │
│     spl-token transfer                   │
│     --owner P2E_POOL_KEYPAIR            │
│  3. Отправить на кошелёк игрока          │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│  КОШЕЛЁК ИГРОКА                          │
│  +9,500 TAMA (после fee)                 │
└─────────────────────────────────────────┘
```

---

## 🔄 ДВА ВАРИАНТА РАБОТЫ

### ВАРИАНТ 1: MINT ПО ТРЕБОВАНИЮ (Текущая реализация)

```
Как работает:
├─ Payer keypair имеет mint authority
├─ При выводе: создаются НОВЫЕ токены (mint)
├─ Отправляются на кошелёк игрока
└─ P2E Pool НЕ используется напрямую

Плюсы:
✅ Не нужно предварительно распределять токены
✅ Mint по требованию (экономия)
✅ Простая реализация

Минусы:
❌ P2E Pool не участвует напрямую
❌ Нет контроля над Daily Pool
❌ Может создать больше токенов чем в пуле
```

### ВАРИАНТ 2: TRANSFER ИЗ P2E POOL (Правильная реализация)

```
Как работает:
├─ P2E Pool получает 400M TAMA заранее
├─ При выводе: transfer ИЗ P2E Pool
├─ Отправляются на кошелёк игрока
└─ P2E Pool баланс уменьшается

Плюсы:
✅ P2E Pool участвует напрямую
✅ Контроль над Daily Pool
✅ Прозрачность (видно баланс пула)
✅ Соответствует токеномике

Минусы:
❌ Нужно предварительно распределить токены
❌ Нужно следить за балансом пула
```

---

## 🎯 КАК ДОЛЖНО РАБОТАТЬ С P2E POOL

### Правильная схема:

```
ШАГ 1: ПРЕДВАРИТЕЛЬНОЕ РАСПРЕДЕЛЕНИЕ
├─ Mint 400M TAMA на P2E Pool wallet
├─ Адрес: HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw
└─ Баланс P2E Pool: 400,000,000 TAMA

ШАГ 2: ИГРОК ВЫВОДИТ ТОКЕНЫ
├─ /withdraw 10000
├─ Проверка: P2E Pool баланс >= 9,500 TAMA
├─ Transfer ИЗ P2E Pool:
│   spl-token transfer \
│     --owner P2E_POOL_KEYPAIR \  ← ИЗ P2E Pool!
│     --from P2E_POOL_TOKEN_ACCOUNT \
│     9500 \
│     USER_WALLET
└─ P2E Pool баланс: 400M → 399,990,500 TAMA

ШАГ 3: FEE РАСПРЕДЕЛЕНИЕ
├─ 60% (300 TAMA) → BURN (виртуально)
├─ 30% (150 TAMA) → Вернуть в P2E Pool (виртуально)
└─ 10% (50 TAMA) → Team wallet (виртуально)
```

---

## 📊 ТЕКУЩАЯ VS ПРАВИЛЬНАЯ РЕАЛИЗАЦИЯ

### ТЕКУЩАЯ (Mint по требованию):

```php
// api/tama_supabase.php (текущая реализация)
$payerKeypair = 'payer-keypair.json';  // ← Технический кошелёк

spl-token transfer \
  --owner payer-keypair.json \  // ← Mint authority
  --fee-payer payer-keypair.json

// Проблема:
// ❌ P2E Pool НЕ используется
// ❌ Токены создаются из mint authority
// ❌ Нет контроля над Daily Pool
```

### ПРАВИЛЬНАЯ (Transfer из P2E Pool):

```php
// Правильная реализация
$p2ePoolKeypair = 'p2e-pool-keypair.json';  // ← P2E Pool wallet
$p2ePoolAddress = 'HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw';

// Проверить баланс P2E Pool
$p2ePoolBalance = checkP2EPoolBalance($p2ePoolKeypair);

if ($p2ePoolBalance < $amountSent) {
    return ['error' => 'P2E Pool insufficient balance'];
}

// Transfer ИЗ P2E Pool
spl-token transfer \
  --owner p2e-pool-keypair.json \  // ← ИЗ P2E Pool!
  --fee-payer payer-keypair.json \
  9500 \
  USER_WALLET

// Обновить баланс P2E Pool в базе
updateP2EPoolBalance($p2ePoolBalance - $amountSent);
```

---

## 🔧 ЧТО НУЖНО ИЗМЕНИТЬ

### 1. Создать P2E Pool Keypair:

```bash
# Создать keypair для P2E Pool
solana-keygen new --outfile p2e-pool-keypair.json

# Узнать адрес
solana-keygen pubkey p2e-pool-keypair.json
# Должен быть: HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw
```

### 2. Распределить токены на P2E Pool:

```bash
# Mint 400M TAMA на P2E Pool wallet
spl-token mint \
  Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY \
  400000000 \
  HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw \
  --owner payer-keypair.json \
  --fee-payer payer-keypair.json \
  --url https://api.devnet.solana.com
```

### 3. Изменить код вывода:

```php
// api/tama_supabase.php
// ИЗМЕНИТЬ:
$payerKeypair = 'payer-keypair.json';  // ← Текущее

// НА:
$p2ePoolKeypair = getenv('P2E_POOL_KEYPAIR_PATH') ?: __DIR__ . '/../p2e-pool-keypair.json';
$p2ePoolAddress = 'HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw';

// Проверить баланс P2E Pool
$p2ePoolBalance = getP2EPoolBalance($p2ePoolKeypair, $tamaMint, $rpcUrl);

if ($p2ePoolBalance < $amountSent) {
    http_response_code(400);
    echo json_encode(['error' => 'P2E Pool insufficient balance']);
    return;
}

// Transfer ИЗ P2E Pool
$cmd = [
    'spl-token',
    'transfer',
    $tamaMint,
    (string)$amountSent,
    $wallet_address,
    '--fund-recipient',
    '--fee-payer', $payerKeypair,  // ← Платит за транзакцию
    '--owner', $p2ePoolKeypair,     // ← ИЗ P2E Pool!
    '--url', $rpcUrl,
    '--output', 'json'
];
```

---

## 📊 СРАВНЕНИЕ

| Параметр | Текущая (Mint) | Правильная (P2E Pool) |
|----------|----------------|------------------------|
| **Источник токенов** | Mint authority | P2E Pool wallet |
| **Адрес** | payer-keypair.json | p2e-pool-keypair.json |
| **Баланс** | Не контролируется | Контролируется (400M) |
| **Daily Pool** | Не учитывается | Учитывается |
| **Прозрачность** | Низкая | Высокая |
| **Соответствие токеномике** | ❌ Нет | ✅ Да |

---

## ✅ РЕКОМЕНДАЦИЯ

### Для Production:

```
1. ✅ Создать p2e-pool-keypair.json
2. ✅ Распределить 400M TAMA на P2E Pool
3. ✅ Изменить код вывода (использовать P2E Pool)
4. ✅ Добавить проверку баланса P2E Pool
5. ✅ Логировать все выводы из P2E Pool
```

### Для Devnet (текущее):

```
Можно оставить как есть (mint по требованию):
├─ Проще для тестирования
├─ Не нужно предварительно распределять
└─ Для production переключить на P2E Pool
```

---

## 🎯 ИТОГО

### Текущая реализация:
- ✅ Использует `payer-keypair.json` (mint authority)
- ❌ P2E Pool НЕ участвует напрямую
- ❌ Токены минтится по требованию

### Правильная реализация:
- ✅ Использует `p2e-pool-keypair.json` (P2E Pool)
- ✅ P2E Pool участвует напрямую
- ✅ Transfer ИЗ P2E Pool (не mint)

### Что нужно сделать:
1. Создать P2E Pool keypair
2. Распределить 400M TAMA на P2E Pool
3. Изменить код вывода (использовать P2E Pool)
4. Добавить проверку баланса

---

**P2E Pool ДОЛЖЕН быть источником токенов для игроков!** ✅

