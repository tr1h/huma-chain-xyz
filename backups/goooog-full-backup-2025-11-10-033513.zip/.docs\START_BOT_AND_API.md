# 🚀 Запуск Бота и API вместе

## 📋 Что нужно:

### **Обязательно:**
- ✅ Python 3.10+ (для бота)
- ✅ Telegram Bot Token

### **Опционально (для API):**
- ⚠️ PHP 7.4+ (для API сервера)
- ⚠️ Supabase Database Password

---

## 🚀 Быстрый запуск:

### **Вариант 1: Всё вместе (рекомендуется)**

```powershell
cd C:\goooog
.\start_bot_and_api.ps1
```

**Что произойдет:**
1. Запустится API сервер на `http://localhost:8002` (если PHP установлен)
2. Запустится бот в отдельном окне
3. Оба будут работать одновременно

---

## 🔧 Настройка:

### **1. Указать Supabase Database Password:**

Открой `api/start_api.ps1` и `start_bot_and_api.ps1`:
```powershell
$env:SUPABASE_DB_PASSWORD = "твой_пароль_от_supabase"
```

**Где взять пароль:**
1. Зайди в Supabase Dashboard
2. Settings → Database
3. Connection string → найди пароль

---

## 📊 Что запускается:

### **API Server:**
- **URL:** `http://localhost:8002/api/tama`
- **Endpoints:** `/test`, `/balance`, `/withdrawal/request`, и т.д.
- **Окно:** PowerShell (видимое)

### **Telegram Bot:**
- **Username:** @GotchiGameBot
- **Окно:** PowerShell (видимое)

---

## 🎯 Проверка работы:

### **1. Проверить API:**
Открой в браузере:
```
http://localhost:8002/api/tama/test
```

Должен вернуть:
```json
{
  "success": true,
  "message": "Database connection successful"
}
```

### **2. Проверить бота:**
1. Открой Telegram
2. Найди @GotchiGameBot
3. Отправь `/start`
4. Бот должен ответить

---

## ⚠️ Если PHP не установлен:

**Бот будет работать, но:**
- ❌ Withdrawal через API не будет работать
- ❌ Withdrawal history не будет работать
- ✅ Все остальные функции работают

**Решение:**
1. Установи PHP: https://www.php.net/downloads
2. Или используй бот без API (основные функции работают)

---

## 🔄 Управление:

### **Остановить всё:**
1. Закрой оба окна PowerShell
2. Или нажми `Ctrl+C` в каждом окне

### **Перезапустить:**
Просто запусти `start_bot_and_api.ps1` снова

---

## 📝 Структура:

```
C:\goooog\
├── start_bot_and_api.ps1  ← Запускает всё вместе
├── bot/
│   ├── start_bot_visible.ps1  ← Запускает только бота
│   └── bot.py
└── api/
    ├── start_api.ps1  ← Запускает только API
    └── tama_supabase.php
```

---

## ✅ Готово!

Теперь можешь запускать бота и API одной командой!

