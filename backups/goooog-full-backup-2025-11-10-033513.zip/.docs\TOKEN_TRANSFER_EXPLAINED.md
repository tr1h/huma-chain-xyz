# 💸 КАК РАБОТАЕТ ОТПРАВКА ТОКЕНОВ

## ❓ ВОПРОС: "Будет ли количество уменьшаться на mint address после отправки?"

**ОТВЕТ:** НЕТ! Total Supply НЕ меняется при transfer. Уменьшается только баланс кошелька-отправителя.

---

## 🔍 ЧТО ТАКОЕ MINT ADDRESS?

### Mint Address: `Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY`

```
Это НЕ кошелек!
Это адрес ТОКЕНА на Solana.

Mint Address показывает:
├─ Total Supply (общее количество созданных токенов)
├─ Decimals (9 для TAMA)
├─ Mint Authority (кто может создавать новые токены)
└─ НО токены НЕ хранятся на mint address!
```

**Токены хранятся в Token Accounts у каждого кошелька!**

---

## 📊 ЧТО ПРОИСХОДИТ ПРИ ОТПРАВКЕ?

### При `spl-token transfer` (отправка):

```
ДО отправки:
├─ P2E Pool: 400,000,000 TAMA
├─ Team: 200,000,000 TAMA
└─ Total Supply: 1,000,000,000 TAMA (на mint address)

Отправка: P2E Pool → Team (10,000,000 TAMA)

ПОСЛЕ отправки:
├─ P2E Pool: 390,000,000 TAMA ⬇️ (уменьшился!)
├─ Team: 210,000,000 TAMA ⬆️ (увеличился!)
└─ Total Supply: 1,000,000,000 TAMA ➡️ (НЕ изменился!)
```

**Вывод:** Total Supply НЕ меняется, только балансы кошельков!

---

## 🆚 СРАВНЕНИЕ: TRANSFER vs MINT

### 1. TRANSFER (отправка с кошелька):

```bash
spl-token transfer \
  Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY \
  10000000 \
  TEAM_WALLET_ADDRESS \
  --owner p2e-pool-keypair.json
```

**Что происходит:**
```
✅ Баланс P2E Pool: -10,000,000 TAMA
✅ Баланс Team: +10,000,000 TAMA
❌ Total Supply: НЕ меняется (1,000,000,000 TAMA)
```

### 2. MINT (создание новых токенов):

```bash
spl-token mint \
  Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY \
  10000000 \
  TEAM_WALLET_ADDRESS \
  --owner tama-mint-keypair.json
```

**Что происходит:**
```
✅ Баланс Team: +10,000,000 TAMA
✅ Total Supply: +10,000,000 TAMA (1,010,000,000 TAMA)
❌ P2E Pool: НЕ меняется
```

---

## 📋 ТАБЛИЦА ИЗМЕНЕНИЙ

| Операция | Отправитель | Получатель | Total Supply |
|----------|-------------|------------|--------------|
| **Transfer** | ⬇️ Уменьшается | ⬆️ Увеличивается | ➡️ НЕ меняется |
| **Mint** | ➡️ НЕ меняется | ⬆️ Увеличивается | ⬆️ Увеличивается |
| **Burn** | ⬇️ Уменьшается | ➡️ НЕ меняется | ⬇️ Уменьшается |

---

## 🎯 ПРАКТИЧЕСКИЕ ПРИМЕРЫ

### Пример 1: Отправка с P2E Pool на Team

```
ДО:
├─ P2E Pool: 400,000,000 TAMA
├─ Team: 200,000,000 TAMA
└─ Total Supply: 1,000,000,000 TAMA

Отправка: 50,000,000 TAMA

ПОСЛЕ:
├─ P2E Pool: 350,000,000 TAMA ⬇️
├─ Team: 250,000,000 TAMA ⬆️
└─ Total Supply: 1,000,000,000 TAMA ➡️
```

### Пример 2: Минтинг новых токенов

```
ДО:
├─ Team: 200,000,000 TAMA
└─ Total Supply: 1,000,000,000 TAMA

Mint: 50,000,000 TAMA → Team

ПОСЛЕ:
├─ Team: 250,000,000 TAMA ⬆️
└─ Total Supply: 1,050,000,000 TAMA ⬆️
```

---

## ✅ ИТОГО

### При отправке (`spl-token transfer`):

```
✅ Баланс отправителя УМЕНЬШАЕТСЯ
✅ Баланс получателя УВЕЛИЧИВАЕТСЯ
❌ Total Supply НЕ меняется
❌ Mint Address НЕ меняется
```

### При минтинге (`spl-token mint`):

```
✅ Баланс получателя УВЕЛИЧИВАЕТСЯ
✅ Total Supply УВЕЛИЧИВАЕТСЯ
❌ Отправителя нет (создаются новые токены)
```

---

## 🔗 ГДЕ СМОТРЕТЬ?

### Total Supply (на mint address):
```
https://explorer.solana.com/address/Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY?cluster=devnet
```

### Баланс конкретного кошелька:
```
https://explorer.solana.com/address/WALLET_ADDRESS?cluster=devnet
```

---

**Вывод:** При отправке токенов Total Supply НЕ меняется, уменьшается только баланс кошелька-отправителя! ✅

