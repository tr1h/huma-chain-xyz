# 🔍 Настройка подключения к Supabase

## 📋 Где найти Connection String:

### **В Supabase Dashboard:**

1. **Settings** → **Database**
2. Найди вкладку **"Connection string"** или **"Connection info"** (не "Connection pooling")
3. Скопируй хост из строки подключения

**Обычно выглядит так:**
```
postgresql://postgres:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres
```

---

## 🔧 Альтернативное решение: REST API

Вместо прямого подключения к PostgreSQL можно использовать **Supabase REST API**!

### **Преимущества:**
- ✅ Не нужен прямой доступ к БД
- ✅ Работает через HTTPS
- ✅ Уже настроен в проекте (`SUPABASE_URL` и `SUPABASE_KEY`)
- ✅ Проще и надежнее

### **Как переключиться:**

API уже использует REST API через Supabase JS SDK в других частях проекта. Можно переписать PHP API на использование REST API вместо прямого подключения.

---

## 💡 Быстрое решение:

**Попробуй найти Connection String в Dashboard:**
1. Settings → Database
2. Вкладка "Connection string" (не "Connection pooling")
3. Скопируй хост оттуда

**Или используй стандартный формат:**
- Pooling: `aws-0-[region].pooler.supabase.com:6543`
- Direct: `db.zfrazyupameidxpjihrh.supabase.co:5432`

---

## ✅ Что делать сейчас:

1. Найди Connection String в Dashboard
2. Пришли хост — обновлю настройки
3. Или скажи, если хочешь перейти на REST API

