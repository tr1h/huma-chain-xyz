# 🎁 INITIAL ALLOCATION - ЧТО ЭТО И НУЖНО ЛИ?

## ❓ ВОПРОС: "Add an initial allocation - Amount released immediately at the specified date before the vesting contract starts - а это?"

**ОТВЕТ:** Initial Allocation = сумма токенов, которая разблокируется **СРАЗУ** в определенную дату **ДО** начала vesting contract.

---

## 🎯 ПРОСТОЕ ОБЪЯСНЕНИЕ

### **Initial Allocation = "Предварительная разблокировка"**

```
БЕЗ Initial Allocation:
├─ Start Date: May 06 2026 (через 6 месяцев)
├─ До этого: 0 TAMA разблокировано ❌
└─ После Start: начинается постепенная разблокировка

С Initial Allocation:
├─ Initial Date: например, Dec 2025 (до Start)
├─ Initial Amount: например, 10M TAMA
├─ Разблокировано СРАЗУ: 10M TAMA ✅ (в Dec 2025)
├─ Start Date: May 06 2026
└─ После Start: разблокировка оставшихся 190M TAMA
```

---

## 📊 ПРИМЕРЫ

### **Пример 1: БЕЗ Initial Allocation (наш случай)**

```
Timeline:
├─ Nov 2025: 0 TAMA (создание stream)
├─ May 2026: 0 TAMA (cliff, начало vesting)
├─ May 2026+: Постепенная разблокировка 200M TAMA
└─ Nov 2029: 200M TAMA (полностью разблокировано)
```

**Результат:** Полная блокировка на 6 месяцев ✅

---

### **Пример 2: С Initial Allocation (НЕ наш случай)**

```
Timeline:
├─ Nov 2025: 0 TAMA (создание stream)
├─ Dec 2025: 10M TAMA разблокировано СРАЗУ ✅ (initial allocation)
├─ May 2026: 10M TAMA (cliff, начало vesting)
├─ May 2026+: Постепенная разблокировка 190M TAMA
└─ Nov 2029: 200M TAMA (полностью разблокировано)
```

**Результат:** Часть токенов разблокирована ДО cliff ❌

---

## ❌ ДЛЯ НАШЕГО СЛУЧАЯ: НЕ НУЖЕН!

### **Почему НЕ включать Initial Allocation:**

```
✅ Мы хотим ПОЛНУЮ блокировку на 6 месяцев
✅ Cliff = 0% означает 0 TAMA на cliff
✅ Initial allocation нарушит полную блокировку
✅ Это противоречит нашей цели (cliff 6 месяцев)
```

---

## ✅ РЕКОМЕНДАЦИЯ

### **Оставь "Add an initial allocation" ВЫКЛЮЧЕННЫМ!**

```
Текущее: Выключено ✅
Оставь: Выключено ✅
```

**Почему:**
- ✅ Мы хотим полную блокировку на 6 месяцев
- ✅ Cliff = 0% означает 0 TAMA до начала vesting
- ✅ Initial allocation даст токены ДО cliff (не нужно!)

---

## 🎯 КОГДА ИСПОЛЬЗОВАТЬ INITIAL ALLOCATION

### **Initial Allocation полезен когда:**

```
1. Хочешь дать часть токенов СРАЗУ
2. Например: 10% сразу, 90% в vesting
3. Для мотивации команды (часть сразу)
```

**Пример:**
```
Total: 200M TAMA
├─ Initial Allocation: 20M TAMA (10% сразу в Dec 2025)
└─ Vesting: 180M TAMA (90% в vesting с May 2026)
```

**НО:** Это НЕ наш случай! Мы хотим полную блокировку.

---

## 💡 ИТОГО

### **Для нашего vesting:**

```
Initial Allocation: ВЫКЛЮЧЕНО ✅
Cliff: 0% (полная блокировка) ✅
Start: через 6 месяцев ✅
```

**Это даст:**
- ✅ Полную блокировку на 6 месяцев
- ✅ 0 TAMA разблокировано до cliff
- ✅ Постепенная разблокировка после cliff

---

**Оставь "Add an initial allocation" ВЫКЛЮЧЕННЫМ!** ✅

