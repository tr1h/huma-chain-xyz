# 🔒 БЛОКИРОВКА ТОКЕНОВ - ЛУЧШИЕ ПРАКТИКИ

## 🎯 ЦЕЛЬ: Разобраться как успешные проекты блокируют токены

---

## 📊 АНАЛИЗ УСПЕШНЫХ SOLANA ПРОЕКТОВ

### 1. **Solana Foundation Projects**

#### Метод: **Multi-Sig + Vesting Contracts**

```
Примеры:
├─ Serum (SERUM)
├─ Raydium (RAY)
└─ Bonfida (FIDA)

Метод:
├─ Multi-sig wallet (3-5 ключей)
├─ Vesting через Bonfida или Streamflow
├─ Прозрачность на блокчейне
└─ Регулярные отчеты сообществу
```

**Плюсы:**
- ✅ Максимальная безопасность
- ✅ Доверие инвесторов
- ✅ Прозрачность
- ✅ Защита от единичного решения

**Минусы:**
- ❌ Сложнее настроить
- ❌ Нужны доверенные лица
- ❌ Дороже (multi-sig транзакции)

---

### 2. **DeFi Projects (Jupiter, Orca, etc.)**

#### Метод: **Streamflow Vesting + DEX Lock**

```
Примеры:
├─ Jupiter (JUP)
├─ Orca (ORCA)
└─ Mango (MNGO)

Метод:
├─ Team tokens: Streamflow vesting (4-5 лет)
├─ Liquidity: Locked в DEX (Raydium/Jupiter)
├─ Community: Multi-sig (3 из 5)
└─ Transparency dashboard
```

**Плюсы:**
- ✅ Проверенный метод (Streamflow)
- ✅ Автоматическая разблокировка
- ✅ UI для просмотра vesting
- ✅ Низкая стоимость

**Минусы:**
- ❌ Зависимость от Streamflow
- ❌ Нужен SOL для создания stream

---

### 3. **Gaming Projects (Star Atlas, etc.)**

#### Метод: **Timelock + Multi-Sig**

```
Примеры:
├─ Star Atlas (ATLAS)
├─ Aurory (AURY)
└─ Genopets (GENE)

Метод:
├─ Team: Timelock (1-2 года) + Multi-sig
├─ Liquidity: DEX lock
├─ Treasury: Multi-sig (4 из 7)
└─ Community: DAO governance
```

**Плюсы:**
- ✅ Простота (timelock)
- ✅ Гибкость
- ✅ Можно комбинировать

**Минусы:**
- ❌ После разблокировки можно всё вывести
- ❌ Нет постепенной разблокировки

---

### 4. **Meme Coins / Community Projects**

#### Метод: **Manual Lock (честное слово)**

```
Примеры:
├─ BONK
├─ WIF
└─ Многие новые проекты

Метод:
├─ Просто "не трогать" кошельки
├─ Публичные обещания
├─ Community trust
└─ Для mainnet - переходят на vesting
```

**Плюсы:**
- ✅ Простота
- ✅ Нет затрат
- ✅ Быстро

**Минусы:**
- ❌ Нет технической защиты
- ❌ Низкое доверие
- ❌ Риск нарушения

---

## 🏆 ТОП-3 МЕТОДА (по популярности)

### 1. **Streamflow Vesting** (60% проектов) ✅

**Почему популярен:**
- ✅ Проверенный и надежный
- ✅ Простой в использовании
- ✅ Прозрачность на блокчейне
- ✅ UI для просмотра
- ✅ Низкая стоимость (~0.1 SOL)

**Используют:**
- Jupiter (JUP)
- Orca (ORCA)
- Mango (MNGO)
- Многие DeFi проекты

**Как работает:**
```
1. Токены отправляются в Streamflow contract
2. Contract блокирует токены
3. Разблокировка по расписанию (linear)
4. Можно проверить на Explorer
5. Нельзя отменить (если cancelable: false)
```

---

### 2. **Multi-Sig Wallet** (25% проектов) ✅

**Почему популярен:**
- ✅ Максимальная безопасность
- ✅ Защита от единичного решения
- ✅ Гибкость
- ✅ Можно комбинировать с vesting

**Используют:**
- Solana Foundation проекты
- Крупные DeFi протоколы
- Институциональные проекты

**Как работает:**
```
1. Создаёшь multi-sig wallet (например, 3 из 5)
2. Токены на multi-sig адресе
3. Для отправки нужно 3 подписи
4. Ты держишь только 1-2 ключа
5. Остальные у доверенных лиц
```

---

### 3. **Bonfida Token Vesting** (10% проектов) ✅

**Почему популярен:**
- ✅ Используется Solana Foundation
- ✅ Проверенный код
- ✅ Open source
- ✅ Прозрачность

**Используют:**
- Некоторые Foundation проекты
- Проекты требующие максимальной прозрачности

**Как работает:**
```
1. Деплой Bonfida vesting contract
2. Создание vesting schedule
3. Токены блокируются в контракте
4. Разблокировка по расписанию
```

---

## 💡 РЕКОМЕНДАЦИИ ДЛЯ НАШЕГО ПРОЕКТА

### 🎯 ОПТИМАЛЬНАЯ СТРАТЕГИЯ

#### **Комбинированный подход:**

```
1. Team (200M) → Streamflow Vesting ✅
   ├─ 4 года vesting
   ├─ 6 месяцев cliff
   ├─ Linear unlock
   └─ Cancelable: false

2. Liquidity (100M) → DEX Lock ✅
   ├─ Заблокировать на Raydium/Jupiter
   ├─ Прозрачно на блокчейне
   └─ Нельзя вывести до листинга

3. Reserve (50M) → Multi-Sig ✅
   ├─ 3 из 5 ключей
   ├─ Ты держишь 1 ключ
   ├─ Остальные у доверенных лиц
   └─ Только для emergency

4. Marketing (150M) → Active ✅
   ├─ Можно использовать
   └─ Прозрачные отчеты

5. Community (100M) → Active ✅
   ├─ Можно использовать
   └─ Прозрачные отчеты
```

---

## 📋 ДЕТАЛЬНЫЙ ПЛАН

### **ЭТАП 1: Team Tokens (200M) - Streamflow**

#### Почему Streamflow:
- ✅ Самый популярный метод (60% проектов)
- ✅ Проверенный и надежный
- ✅ Простой в использовании
- ✅ Прозрачность
- ✅ Низкая стоимость

#### Настройка:

```bash
# 1. Установить Streamflow CLI
npm install -g @streamflow/cli

# 2. Создать vesting stream
streamflow create-stream \
  --cluster mainnet-beta \
  --token TAMA_MINT_ADDRESS \
  --amount 200000000 \
  --recipient TEAM_WALLET_ADDRESS \
  --start-time $(date +%s) \
  --end-time $(($(date +%s) + 126144000)) \
  --cliff-time $(($(date +%s) + 15552000)) \
  --cancelable false \
  --keypair team-wallet-keypair.json

# Параметры:
# - Duration: 126,144,000 сек = 4 года
# - Cliff: 15,552,000 сек = 6 месяцев
# - Cancelable: false (нельзя отменить!)
```

#### Результат:
- ✅ Токены физически заблокированы
- ✅ Нельзя отправить даже с keypair
- ✅ Разблокировка автоматически
- ✅ Прозрачно на Explorer

---

### **ЭТАП 2: Liquidity (100M) - DEX Lock**

#### Почему DEX Lock:
- ✅ Стандартная практика
- ✅ Прозрачно на блокчейне
- ✅ Автоматическая блокировка при добавлении ликвидности
- ✅ Нельзя вывести до окончания lock period

#### Настройка:

```bash
# 1. Добавить ликвидность на Raydium/Jupiter
# 2. Выбрать "Lock Liquidity" опцию
# 3. Установить lock period (например, 1-2 года)
# 4. Токены автоматически блокируются
```

#### Результат:
- ✅ Токены заблокированы в DEX
- ✅ Нельзя вывести до окончания lock
- ✅ Прозрачно на блокчейне
- ✅ Стандартная практика

---

### **ЭТАП 3: Reserve (50M) - Multi-Sig**

#### Почему Multi-Sig:
- ✅ Максимальная безопасность
- ✅ Защита от единичного решения
- ✅ Гибкость (можно использовать при необходимости)
- ✅ Доверие сообщества

#### Настройка:

```bash
# 1. Создать multi-sig wallet
solana-keygen new --outfile reserve-key1.json
solana-keygen new --outfile reserve-key2.json
solana-keygen new --outfile reserve-key3.json
solana-keygen new --outfile reserve-key4.json
solana-keygen new --outfile reserve-key5.json

# 2. Создать multi-sig account (3 из 5)
# Использовать Solana CLI или UI

# 3. Перевести токены на multi-sig адрес
spl-token transfer \
  TAMA_MINT_ADDRESS \
  50000000 \
  MULTISIG_ADDRESS \
  --owner reserve-keypair.json
```

#### Результат:
- ✅ Нужны 3 подписи для отправки
- ✅ Ты держишь только 1 ключ
- ✅ Защита от единичного решения
- ✅ Можно использовать при emergency

---

## 🆚 СРАВНЕНИЕ МЕТОДОВ

| Метод | Безопасность | Прозрачность | Сложность | Стоимость | Рекомендация |
|-------|--------------|--------------|-----------|-----------|--------------|
| **Streamflow** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐ | ~0.1 SOL | ✅ **Лучший для Team** |
| **Multi-Sig** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ~0.05 SOL | ✅ **Лучший для Reserve** |
| **DEX Lock** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐ | Бесплатно | ✅ **Лучший для Liquidity** |
| **Bonfida** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ~0.1 SOL | ✅ Альтернатива Streamflow |
| **Timelock** | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | ~0.05 SOL | ⚠️ Менее гибкий |
| **Manual** | ⭐ | ⭐ | ⭐ | Бесплатно | ❌ Только для devnet |

---

## 🎯 ФИНАЛЬНАЯ РЕКОМЕНДАЦИЯ

### **Для нашего проекта:**

```
✅ Team (200M) → Streamflow Vesting
   ├─ 4 года, cliff 6 мес
   ├─ Cancelable: false
   └─ Прозрачность

✅ Liquidity (100M) → DEX Lock
   ├─ Raydium/Jupiter
   ├─ Lock period: 1-2 года
   └─ Автоматическая блокировка

✅ Reserve (50M) → Multi-Sig (3 из 5)
   ├─ Ты держишь 1 ключ
   ├─ Остальные у доверенных лиц
   └─ Только для emergency

✅ Marketing (150M) → Active
   ├─ Можно использовать
   └─ Прозрачные отчеты

✅ Community (100M) → Active
   ├─ Можно использовать
   └─ Прозрачные отчеты
```

---

## 📊 СТАТИСТИКА УСПЕШНЫХ ПРОЕКТОВ

### **Что делают топ-проекты:**

```
60% → Streamflow для Team tokens
25% → Multi-Sig для Treasury/Reserve
15% → DEX Lock для Liquidity
10% → Bonfida (альтернатива Streamflow)
5% → Timelock (простой вариант)
```

### **Почему Streamflow популярен:**

```
✅ Проверенный (используют Jupiter, Orca, Mango)
✅ Простой в использовании
✅ Прозрачность
✅ Низкая стоимость
✅ UI для просмотра
✅ Нельзя отменить (если настроено)
```

---

## ✅ ПЛАН ДЕЙСТВИЙ

### **СЕЙЧАС (Devnet):**

```
1. ✅ Понять текущую ситуацию (условная блокировка)
2. ✅ Не трогать Team/Liquidity/Reserve wallets
3. ✅ Тестировать систему
4. ✅ Готовиться к mainnet
```

### **ПЕРЕД MAINNET:**

```
1. ⬜ Установить Streamflow CLI
2. ⬜ Создать vesting stream для Team (200M)
3. ⬜ Настроить Multi-sig для Reserve (50M)
4. ⬜ Подготовить DEX lock для Liquidity (100M)
5. ⬜ Опубликовать адреса vesting contracts
6. ⬜ Создать transparency dashboard
```

### **ПОСЛЕ MAINNET:**

```
1. ⬜ Регулярные отчеты о vesting
2. ⬜ Transparency dashboard
3. ⬜ Community verification
4. ⬜ Monthly reports
```

---

## 🔗 ПОЛЕЗНЫЕ ССЫЛКИ

- **Streamflow:** https://streamflow.finance
- **Bonfida Vesting:** https://github.com/Bonfida/token-vesting
- **Solana Multi-Sig:** https://docs.solana.com/developing/programming-model/runtime#program-derived-addresses
- **Raydium Lock:** https://raydium.io/liquidity/create/
- **Jupiter Lock:** https://jup.ag/

---

## 💡 ИТОГО

### **Лучшая стратегия для нас:**

```
1. Team → Streamflow (как 60% успешных проектов)
2. Liquidity → DEX Lock (стандартная практика)
3. Reserve → Multi-Sig (максимальная безопасность)
4. Marketing/Community → Active (с прозрачностью)
```

**Это даст:**
- ✅ Максимальное доверие сообщества
- ✅ Прозрачность на блокчейне
- ✅ Защиту от нарушений
- ✅ Соответствие лучшим практикам

---

**Готово! Это оптимальная стратегия для нашего проекта!** 🚀

