# 📥 Установка PHP на Windows

## 🚀 Быстрый способ (XAMPP - рекомендуется)

### **Шаг 1: Скачать XAMPP**
1. Перейди на: https://www.apachefriends.org/download.html
2. Скачай **XAMPP для Windows** (последняя версия)
3. Выбери версию с PHP 8.1 или выше

### **Шаг 2: Установить**
1. Запусти установщик
2. Выбери компоненты: **Apache** и **PHP** (минимум)
3. Установи в `C:\xampp` (по умолчанию)
4. Заверши установку

### **Шаг 3: Добавить PHP в PATH**
1. Открой **Системные переменные среды**:
   - Win + R → `sysdm.cpl` → вкладка "Дополнительно" → "Переменные среды"
2. Найди переменную **Path** в "Системные переменные"
3. Нажми **Изменить** → **Создать**
4. Добавь: `C:\xampp\php`
5. Нажми **ОК** везде

### **Шаг 4: Проверить**
Открой новый PowerShell и выполни:
```powershell
php -v
```

Должно показать версию PHP (например, `PHP 8.1.0`)

---

## 🔧 Альтернативный способ (Только PHP)

### **Шаг 1: Скачать PHP**
1. Перейди на: https://windows.php.net/download/
2. Скачай **PHP 8.1+ Thread Safe** (ZIP архив)
3. Распакуй в `C:\php`

### **Шаг 2: Добавить в PATH**
1. Открой **Системные переменные среды**
2. Добавь `C:\php` в переменную **Path**

### **Шаг 3: Настроить**
1. Скопируй `php.ini-development` в `php.ini`
2. Открой `php.ini` и раскомментируй:
   ```ini
   extension=pdo_pgsql
   extension=pgsql
   ```

### **Шаг 4: Проверить**
```powershell
php -v
```

---

## ✅ После установки

### **Запустить API:**
```powershell
cd C:\goooog
.\start_bot_and_api.ps1
```

Или только API:
```powershell
cd C:\goooog\api
.\start_api.ps1
```

---

## 🐛 Проблемы?

### **"php не является внутренней или внешней командой"**
- Перезапусти PowerShell (или перезагрузи компьютер)
- Проверь, что PHP добавлен в PATH
- Проверь путь: `C:\xampp\php\php.exe` должен существовать

### **"Extension pdo_pgsql not found"**
- Открой `php.ini`
- Раскомментируй строки:
  ```ini
  extension=pdo_pgsql
  extension=pgsql
  ```
- Перезапусти API

---

## 📚 Полезные ссылки

- **XAMPP:** https://www.apachefriends.org/
- **PHP для Windows:** https://windows.php.net/download/
- **Документация PHP:** https://www.php.net/manual/ru/

---

## ✅ Готово!

После установки PHP, API будет работать вместе с ботом!

