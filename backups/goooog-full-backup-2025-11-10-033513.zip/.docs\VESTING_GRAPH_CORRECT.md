# ✅ ГРАФИК VESTING - ПРАВИЛЬНО НАСТРОЕН!

## 📊 ПРОВЕРКА ГРАФИКА

### **Текущий график показывает:**

```
Начало: May 06, 2026 ✅ (через 6 месяцев)
Конец: May 6, 2030 ✅ (4 года от начала)
Разблокировка: Linear (0% → 100%) ✅
Длительность: 4 года ✅
```

---

## ✅ ВСЕ ПРАВИЛЬНО!

### **Параметры соответствуют плану:**

```
✅ Start Date: May 06, 2026 (через 6 месяцев)
✅ End Date: May 6, 2030 (4 года от start)
✅ Cliff: 0% (полная блокировка на cliff)
✅ Duration: 4 года (48 месяцев)
✅ Unlock: Linear (постепенно)
```

---

## 📋 ЧТО ДОЛЖНО БЫТЬ НА СЛЕДУЮЩЕМ ЭКРАНЕ

После нажатия "Continue" или "Next", нужно будет ввести:

```
Amount: 200000000 (200M TAMA)
Recipient: AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR
```

---

## 🎯 ИТОГОВАЯ КОНФИГУРАЦИЯ

```
✅ Token: Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY
✅ Vesting Duration: 48 Months (4 года)
✅ Unlock schedule: Daily
✅ Start Date: May 06, 2026
✅ End Date: May 6, 2030
✅ Cliff: 0% (полная блокировка)
✅ Who can change recipient: Neither
✅ Cancellable: false
✅ Auto-claim: false
✅ Initial allocation: false
```

---

**Все правильно! Можно продолжать!** 🚀

