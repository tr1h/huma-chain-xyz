# 🚀 СОЗДАНИЕ VESTING STREAM В STREAMFLOW - ПОШАГОВАЯ ИНСТРУКЦИЯ

## ✅ ТЫ УЖЕ В STREAMFLOW!

Вижу что ты:
- ✅ Подключен к кошельку (AQr5B...kWXVR)
- ✅ На devnet (правильно для тестирования)
- ✅ В веб-интерфейсе Streamflow

---

## 📋 ШАГИ ДЛЯ СОЗДАНИЯ VESTING STREAM

### **Шаг 1: Перейти на страницу Vesting**

В левом меню (sidebar) найди:
```
Vesting
```

**Нажми на "Vesting"** в меню слева.

---

### **Шаг 2: Создать новый Vesting Stream**

На странице Vesting найди кнопку:
```
+ Create Stream
```
или
```
New Stream
```

**Нажми на эту кнопку.**

---

### **Шаг 3: Заполнить параметры**

В форме создания stream введи:

#### **Основные параметры:**

```
Token Address: Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY
Amount: 200000000 (200M TAMA)
Recipient: AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR
```

#### **Временные параметры:**

```
Start Date: 2026-05-06 (через 6 месяцев от сегодня)
End Date: 2029-11-06 (через 4 года от сегодня)
Cliff Date: 2026-05-06 (совпадает со start)
```

#### **Настройки:**

```
Cliff Amount: 0 (полная блокировка на cliff)
Period: 1 second (linear unlock)
Cancelable: false (нельзя отменить)
Can Topup: false
Transferable: false
```

---

### **Шаг 4: Подтвердить транзакцию**

1. Проверь все параметры
2. Нажми "Create Stream" или "Confirm"
3. Подтверди транзакцию в Phantom
4. Дождись подтверждения

---

### **Шаг 5: Сохранить Stream ID**

После создания:
- ✅ Сохрани Stream ID (адрес stream)
- ✅ Проверь на Explorer: https://explorer.solana.com/address/STREAM_ID?cluster=devnet
- ✅ Опубликуй для прозрачности

---

## 📊 ДЕТАЛЬНЫЕ ПАРАМЕТРЫ

### **Для копирования:**

```
Token Mint: Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY
Amount: 200000000
Recipient: AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR
Start: 2026-05-06 12:00:00 (или текущая дата + 6 месяцев)
End: 2029-11-06 12:00:00 (или текущая дата + 4 года)
Cliff: 2026-05-06 12:00:00 (совпадает со start)
Cliff Amount: 0
Period: 1 second
Cancelable: false
```

---

## ⚠️ ВАЖНЫЕ ЗАМЕЧАНИЯ

### **1. Даты:**

Если Streamflow требует точные даты:
- **Start/Cliff:** Сегодня + 6 месяцев
- **End:** Сегодня + 4 года

Или используй конкретные даты:
- **Start/Cliff:** 2026-05-06
- **End:** 2029-11-06

---

### **2. Amount:**

Введи **200000000** (200 миллионов TAMA)

**НЕ вводи:** 200M, 200,000,000 (с запятыми) - только цифры!

---

### **3. Recipient:**

Это тот же адрес что и sender (team wallet):
```
AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR
```

---

## 🎯 ЧТО ДОЛЖНО ПОЛУЧИТЬСЯ

После создания:

```
✅ Vesting stream создан
✅ 200M TAMA заблокированы в escrow
✅ Разблокировка начнется через 6 месяцев
✅ Полная разблокировка через 4 года
✅ Stream ID сохранен
```

---

## 📋 СЛЕДУЮЩИЕ ШАГИ

После создания stream:

1. ✅ Сохрани Stream ID
2. ✅ Проверь на Explorer
3. ✅ Опубликуй для прозрачности
4. ✅ Добавь в документацию проекта

---

**Готово! Следуй инструкциям выше!** 🚀

