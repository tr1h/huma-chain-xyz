# 🎮 P2E Pool как Source Wallet - Объяснение

## 🤔 Что такое P2E Pool?

**P2E Pool** = "банк" TAMA токенов для игры

```
Address: HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw
Роль: Хранилище всех TAMA токенов для Play-to-Earn
```

---

## 💰 Как Работает TAMA Экономика

### **Off-Chain (в базе данных):**
```
Игрок зарабатывает TAMA:
  • Клики в игре: +50 TAMA
  • Daily reward: +100 TAMA
  • Рефералы: +1,000 TAMA

Баланс: 5,000 TAMA (записано в БД)
         ↓
    Виртуальные токены
    (пока нет реальных токенов on-chain)
```

### **On-Chain (реальные токены):**
```
Игрок минтит Bronze NFT:
  1. Списывается 2,500 TAMA из БД (виртуально)
  2. Backend вызывает on-chain распределение:
     
     FROM: P2E Pool wallet
     ├─ 1,000 TAMA → Burn (уничтожается)
     ├─ 750 TAMA → Treasury (на развитие)
     └─ 750 TAMA → P2E Pool (обратно в пул)
     
  3. Реальные SPL Token transfers на блокчейне!
```

---

## 🔄 Полный Flow

### **1. Начало: Mint TAMA в P2E Pool**
```
Команда минтит 400M TAMA:
  spl-token mint \
    Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY \
    400000000 \
    HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw
  
  P2E Pool balance: 400M TAMA (реальные токены on-chain)
```

### **2. Игроки Зарабатывают (Off-Chain)**
```
Игрок A: играет, кликает, зарабатывает
  Database: tama = 5,000 (виртуально)
  P2E Pool: 400M TAMA (не изменяется)

Игрок B: рефералы, квесты
  Database: tama = 10,000 (виртуально)
  P2E Pool: 400M TAMA (не изменяется)
```

### **3. Bronze NFT Mint (On-Chain)**
```
Игрок A минтит Bronze NFT:
  
  Step 1: Списание из БД
    Database: tama = 5,000 → 2,500 (виртуально)
  
  Step 2: On-Chain Distribution
    P2E Pool → Burn: 1,000 TAMA
    P2E Pool → Treasury: 750 TAMA
    P2E Pool → P2E Pool: 750 TAMA
    
    P2E Pool balance: 400M → 399,998,500 TAMA
    (2,500 TAMA вышло, 750 TAMA вернулось обратно)
    
    Реальные транзакции на блокчейне! ✅
```

### **4. Withdrawal (On-Chain)**
```
Игрок B хочет вывести TAMA на свой wallet:
  
  Database: tama = 10,000 → 0 (списали)
  
  P2E Pool → Player wallet: 9,500 TAMA (после 5% fee)
  
  P2E Pool balance: 399,998,500 → 399,989,000 TAMA
  
  Игрок получил реальные токены! ✅
```

---

## 📊 Почему P2E Pool как Source?

### **Преимущества:**

1. **Централизованное управление:**
   - Все токены в одном месте
   - Легко контролировать supply
   - Можно мониторить баланс

2. **Экономия на fees:**
   - Backend платит fees за транзакции
   - Игрокам не нужен SOL для fees
   - Простой UX для пользователей

3. **Безопасность:**
   - Токены контролируются командой
   - Нет риска потери токенов игроками
   - Можно ограничить withdrawals при необходимости

4. **Гибкость:**
   - Можно менять распределение
   - Можно добавлять новые механики
   - Можно пополнять пул при необходимости

---

## 🔢 Динамическое Распределение (в процентах)

### **Раньше (захардкоженные значения):**
```php
$BRONZE_PRICE = 2500; // фиксировано!
$distribution = [
    'burn' => 1000,     // фиксировано!
    'treasury' => 750,  // фиксировано!
    'p2e_pool' => 750   // фиксировано!
];
```

**Проблема:** Если цена Bronze NFT изменится в admin panel (например, с 2,500 на 3,000 TAMA), распределение останется старым!

---

### **Сейчас (динамическое):**
```php
// Get price from nft_tiers table
$tierResult = supabaseRequest($url, $key, 'GET', 'nft_tiers', [
    'tier_name' => 'eq.Bronze'
]);
$tama_price = $tierResult['data'][0]['tama_price']; // 2500, 3000, etc.

// Distribution in percentages (dynamic!)
$distribution = [
    'burn' => (int)($tama_price * 0.40),      // 40% от актуальной цены
    'treasury' => (int)($tama_price * 0.30),  // 30% от актуальной цены
    'p2e_pool' => (int)($tama_price * 0.30)   // 30% от актуальной цены
];
```

**Преимущества:**
- ✅ Цена изменилась в admin panel → автоматически новое распределение
- ✅ Всегда 40% burn, 30% treasury, 30% p2e pool
- ✅ Не нужно обновлять код при изменении цен

---

## 📝 Примеры

### **Bronze NFT по текущей цене (2,500 TAMA):**
```
Price: 2,500 TAMA
├─ 40% (1,000) → Burn
├─ 30% (750) → Treasury
└─ 30% (750) → P2E Pool

P2E Pool: -2,500 + 750 = -1,750 TAMA чистый расход
```

### **Если цена изменится на 3,000 TAMA:**
```
Price: 3,000 TAMA
├─ 40% (1,200) → Burn
├─ 30% (900) → Treasury
└─ 30% (900) → P2E Pool

P2E Pool: -3,000 + 900 = -2,100 TAMA чистый расход
```

### **Если цена изменится на 5,000 TAMA:**
```
Price: 5,000 TAMA
├─ 40% (2,000) → Burn
├─ 30% (1,500) → Treasury
└─ 30% (1,500) → P2E Pool

P2E Pool: -5,000 + 1,500 = -3,500 TAMA чистый расход
```

---

## 💡 Итог

**P2E Pool** = централизованный кошелек с TAMA токенами

**Роль:**
- Хранит все TAMA для игры
- Источник токенов для withdrawals
- Источник токенов для NFT distributions
- "Банк" проекта

**Преимущества:**
- Простой UX (игрокам не нужен SOL)
- Централизованный контроль
- Гибкость в изменении механик
- Динамическое распределение в процентах

**Чистый расход P2E Pool при Bronze mint:**
```
2,500 TAMA вышло - 750 TAMA вернулось = 1,750 TAMA чистый расход
```

Это нормально! P2E Pool постоянно пополняется через:
- Treasury allocations
- Future token sales
- Community contributions

