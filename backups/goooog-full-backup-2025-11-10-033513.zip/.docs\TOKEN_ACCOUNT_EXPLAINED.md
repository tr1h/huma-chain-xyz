# 🪙 TOKEN ACCOUNT - ЧТО ЭТО И ЗАЧЕМ НУЖЕН

## ❓ ВОПРОС: "Создать Token Account это что и для чего?"

**ОТВЕТ:** Token Account — это **отдельный счет для хранения SPL токенов** (например, TAMA) в Solana. Он **отличается** от обычного wallet account, который хранит только SOL.

---

## 🎯 ПРОСТОЕ ОБЪЯСНЕНИЕ

### **В Solana есть 2 типа счетов:**

```
1. Wallet Account (обычный кошелек)
   ├─ Хранит: SOL (нативная валюта)
   ├─ Создается автоматически
   └─ Адрес: например, AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR

2. Token Account (токеновый счет)
   ├─ Хранит: SPL токены (TAMA, USDC, и т.д.)
   ├─ Нужно создавать отдельно для каждого токена
   └─ Адрес: другой (создается автоматически)
```

---

## 📊 ВИЗУАЛИЗАЦИЯ

### **Без Token Account:**

```
Team Wallet (AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR)
├─ SOL: 0.3 ✅
└─ TAMA: ❌ НЕТ (некуда хранить!)
```

**Проблема:** Нельзя хранить TAMA токены без token account!

---

### **С Token Account:**

```
Team Wallet (AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR)
├─ SOL: 0.3 ✅
└─ Token Account (для TAMA)
   └─ TAMA: 200M ✅
```

**Решение:** Token account создан, можно хранить TAMA!

---

## 🔧 КАК ЭТО РАБОТАЕТ

### **1. Обычный Wallet (для SOL):**

```
Wallet Address: AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR
├─ Хранит: SOL
├─ Создается: Автоматически при создании keypair
└─ Использование: Для транзакций, оплаты fees
```

### **2. Token Account (для TAMA):**

```
Token Account Address: [автоматически создается]
├─ Хранит: TAMA токены
├─ Создается: Вручную командой spl-token create-account
├─ Связан с: Wallet Address (owner)
└─ Использование: Для хранения и перевода TAMA
```

---

## 💡 ЗАЧЕМ НУЖЕН TOKEN ACCOUNT

### **1. Хранение SPL токенов:**

```
Без Token Account:
├─ Нельзя получить TAMA токены
├─ Нельзя хранить TAMA токены
└─ Нельзя отправить TAMA токены

С Token Account:
├─ Можно получить TAMA токены ✅
├─ Можно хранить TAMA токены ✅
└─ Можно отправить TAMA токены ✅
```

### **2. Для Vesting Stream:**

```
Streamflow требует:
├─ Sender должен иметь token account для TAMA
├─ Token account должен содержать токены для vesting
└─ Без token account нельзя создать stream
```

---

## 📋 ПРИМЕР

### **Шаг 1: Проверка Token Account**

```bash
# Проверить есть ли token account
spl-token accounts --owner AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR --url devnet
```

**Результат:**
```
Token                                         Balance  
-------------------------------------------------------
Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY  200000000
```

✅ **Token account уже существует!** (видно по балансу)

---

### **Шаг 2: Если Token Account НЕ существует:**

```bash
# Создать token account
spl-token create-account Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY \
  --owner C:\goooog\team-wallet-keypair.json \
  --url devnet
```

**Что происходит:**
- ✅ Создается новый token account
- ✅ Связан с team wallet (owner)
- ✅ Готов для хранения TAMA токенов

---

## 🎯 В ТВОЕМ СЛУЧАЕ

### **Текущая ситуация:**

```bash
# Проверка показала:
spl-token accounts --owner AQr5BM4FUKumKwdcNMWM1FPVx6qLWssp55HqH4SkWXVR --url devnet

Результат:
Token                                         Balance  
-------------------------------------------------------
Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY  200000000
```

**Вывод:**
- ✅ **Token account УЖЕ существует!**
- ✅ **TAMA токены УЖЕ на нем!**
- ✅ **Готово для vesting!**

**НЕ нужно создавать token account** — он уже есть!

---

## 🔍 КАК ПОНЯТЬ ЕСТЬ ЛИ TOKEN ACCOUNT

### **Способ 1: Проверить баланс**

```bash
spl-token accounts --owner WALLET_ADDRESS --url devnet
```

**Если видишь баланс токенов:**
- ✅ Token account существует
- ✅ Токены на нем

**Если пусто:**
- ❌ Token account не существует
- ❌ Нужно создать

---

### **Способ 2: Попытка перевода**

```bash
# Если попытаться перевести токены без token account
spl-token transfer TOKEN_MINT AMOUNT RECIPIENT

# Ошибка: AccountNotFound
# Это значит: token account не существует
```

---

## 📊 СРАВНЕНИЕ

| Параметр | Wallet Account | Token Account |
|----------|----------------|---------------|
| **Хранит** | SOL | SPL токены (TAMA, USDC, и т.д.) |
| **Создание** | Автоматически | Вручную (`spl-token create-account`) |
| **Адрес** | Один на wallet | Один на каждый токен |
| **Использование** | Для транзакций, fees | Для хранения токенов |
| **Rent** | Минимальный | Требует rent exemption |

---

## 💡 ИТОГО

### **Token Account = отдельный счет для токенов**

```
✅ Нужен для хранения SPL токенов (TAMA, USDC, и т.д.)
✅ Создается отдельно для каждого токена
✅ Связан с wallet account (owner)
✅ Требует rent exemption (~0.002 SOL)
```

### **В твоем случае:**

```
✅ Token account УЖЕ существует
✅ TAMA токены УЖЕ на нем (200M)
✅ Готово для vesting!
```

**НЕ нужно создавать token account** — он уже есть и работает! 🎉

---

**Готово! Теперь понятно что такое Token Account!** 🪙

