# 🔑 Keypairs Explained - Зачем Нужны Оба?

## 🎯 Краткий Ответ

**SOLANA_PAYER_KEYPAIR:**
- 💰 Платит за **transaction fees** (SOL)
- ⚡ Нужен для **каждой** on-chain транзакции
- 🔧 "Рабочий кошелек" для оплаты комиссий

**SOLANA_P2E_POOL_KEYPAIR:**
- 🎮 Хранит **TAMA токены** для распределения
- 📦 Отсюда берутся токены для burn/treasury/p2e
- 💎 "Банк" TAMA токенов

---

## 💰 SOLANA_PAYER_KEYPAIR - Зачем?

### **Проблема: Transaction Fees**

Каждая транзакция на Solana стоит **SOL** (не TAMA!):

```
spl-token transfer ... → Стоит ~0.000005 SOL (fee)
```

**Кто платит?** → Payer wallet!

---

### **Как Это Работает:**

```
User минтит Bronze NFT →
  Backend выполняет 3 транзакции:
  
  1. Burn: 1,000 TAMA → Burn address
     Fee: 0.000005 SOL ← Платит PAYER wallet
  
  2. Treasury: 750 TAMA → Treasury
     Fee: 0.000005 SOL ← Платит PAYER wallet
  
  3. P2E Pool: 750 TAMA → P2E Pool
     Fee: 0.000005 SOL ← Платит PAYER wallet
  
  Total fees: ~0.000015 SOL (очень мало!)
```

**Payer wallet = "рабочий кошелек"** который платит за все fees!

---

### **Почему Не User Платит?**

**Преимущества:**
- ✅ User не нужен SOL (только TAMA)
- ✅ Простой UX (не нужно подключать Phantom)
- ✅ Backend контролирует fees
- ✅ Можем batch транзакции (экономия)

**Альтернатива (если user платит):**
- ❌ User должен иметь SOL
- ❌ Сложный UX (нужен Phantom wallet)
- ❌ User платит fees (неудобно)

---

### **Сколько SOL Нужно?**

**На Devnet:**
- 1 транзакция = ~0.000005 SOL
- 3 транзакции (Bronze mint) = ~0.000015 SOL
- 1000 mints = ~0.015 SOL

**Рекомендация:**
- Держи 1-2 SOL в payer wallet (хватит надолго!)
- Пополняй когда < 0.1 SOL

---

## 🎮 SOLANA_P2E_POOL_KEYPAIR - Зачем?

### **Проблема: Откуда Берутся TAMA?**

Когда user минтит Bronze NFT за 2,500 TAMA:
- User платит 2,500 TAMA (в БД, виртуально)
- Но для on-chain распределения нужны **реальные TAMA токены**!

**Откуда?** → P2E Pool wallet!

---

### **Как Это Работает:**

```
P2E Pool wallet: 400M TAMA (реальные токены on-chain)

User минтит Bronze NFT (2,500 TAMA) →
  P2E Pool отправляет:
  
  1. 1,000 TAMA → Burn (уничтожается)
  2. 750 TAMA → Treasury (на развитие)
  3. 750 TAMA → P2E Pool (обратно!)
  
  P2E Pool balance: 400M - 1,750 = 399,998,250 TAMA
  (2,500 вышло, 750 вернулось = чистый расход 1,750)
```

**P2E Pool = "банк" TAMA токенов** для всех распределений!

---

### **Почему P2E Pool, а Не User?**

**Логика:**
- User зарабатывает TAMA виртуально (в БД)
- P2E Pool хранит реальные токены (on-chain)
- При NFT mint: P2E Pool конвертирует виртуальные → реальные

**Это правильная модель:**
- ✅ User не нужен реальный TAMA wallet
- ✅ Централизованное управление
- ✅ Простой UX

---

## 🔄 Полный Flow

### **Bronze NFT Mint:**

```
Step 1: User платит TAMA (off-chain)
  User balance: 5,000 → 2,500 TAMA (в БД)
  
Step 2: Backend выполняет on-chain распределение
  
  FROM: P2E Pool (SOLANA_P2E_POOL_KEYPAIR)
  ├─ 1,000 TAMA → Burn
  ├─ 750 TAMA → Treasury
  └─ 750 TAMA → P2E Pool (обратно)
  
  FEES: Платит Payer (SOLANA_PAYER_KEYPAIR)
  ├─ Fee 1: 0.000005 SOL
  ├─ Fee 2: 0.000005 SOL
  └─ Fee 3: 0.000005 SOL
  
Step 3: NFT регистрируется в БД
  ✅ User получает NFT
  ✅ NFT boost работает
```

---

## 📊 Сравнение

| Keypair | Что Делает | Что Хранит | Зачем Нужен |
|---------|------------|------------|-------------|
| **PAYER** | Платит fees | SOL (для fees) | Оплата комиссий |
| **P2E_POOL** | Отправляет TAMA | TAMA (токены) | Распределение токенов |

---

## 💡 Аналогия

**Payer Keypair = "Кредитная карта"**
- Платит за все комиссии
- Нужен SOL (не TAMA)
- Используется для каждой транзакции

**P2E Pool Keypair = "Банковский счет"**
- Хранит TAMA токены
- Откуда берутся токены для распределения
- Используется для отправки TAMA

---

## ✅ Итог

**SOLANA_PAYER_KEYPAIR:**
- 💰 Платит SOL за transaction fees
- ⚡ Нужен для каждой on-chain транзакции
- 🔧 "Рабочий кошелек" backend

**SOLANA_P2E_POOL_KEYPAIR:**
- 🎮 Хранит TAMA токены
- 📦 Откуда берутся токены для burn/treasury
- 💎 "Банк" проекта

**Оба нужны для on-chain NFT mint!** 🚀

---

## 🔍 Проверка

**Payer wallet должен иметь:**
```bash
solana balance PAYER_ADDRESS --url devnet
# Должно быть: > 0.1 SOL
```

**P2E Pool должен иметь:**
```bash
spl-token balance Fuqw8Zg17XhHGXfghLYD1fqjxJa1PnmG2MmoqG5pcmLY \
  --owner HPQf1MG8e41MoMayD8iqFmadqZ2NteScx4dQuwc1fCQw \
  --url devnet
# Должно быть: > 1,000,000 TAMA (для тестов)
```

---

**Теперь понятно?** Оба keypair нужны для разных целей! 🔑

